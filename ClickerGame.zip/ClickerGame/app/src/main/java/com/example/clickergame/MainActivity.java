package com.example.clickergame;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.concurrent.atomic.AtomicInteger;

public class MainActivity extends AppCompatActivity {

    Activity activity;

    ImageView KI;
    ImageView fridge;
    ImageView truck;

    TextView CPS;
    TextView score;

    int fridges = 0;
    int trucks = 0;

    boolean fridgeIsVisible;
    boolean truckIsVisible;

    TextView plusOne;
    //ImageView upgradeFridgeImage;
    ImageView upgradeTwoImage;


    ConstraintLayout layout;


    public static AtomicInteger kookies;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        kookies = new AtomicInteger(0);
        fridgeIsVisible = false;
        truckIsVisible = false;
        CPS = findViewById(R.id.CPS);
        KI = findViewById(R.id.KulfiImage);
        score = findViewById(R.id.Kulfis);


        layout = findViewById(R.id.Layout);
        AnimationDrawable animationDrawable = (AnimationDrawable) layout.getBackground();
        animationDrawable.setEnterFadeDuration(2500);
        animationDrawable.setExitFadeDuration(5000);
        animationDrawable.start();

        fridge = findViewById(R.id.fridge);
        truck = findViewById(R.id.truck);
        activity = this;

        final boolean[] ended = {true};

        new fridgeThread().start();




        plusOne = new TextView(this);
        plusOne.setId(View.generateViewId());
        plusOne.setText("+1");
        plusOne.setTextColor(Color.BLACK);
        plusOne.setTextSize(24);
        ConstraintLayout.LayoutParams wrap = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plusOne.setLayoutParams(wrap);

        //ConstraintLayout.LayoutParams wap = new ConstraintLayout.LayoutParams(ConstraintLayout.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        //upgradeFridgeImage.setLayoutParams(wap);

        System.out.println("HIIIIIIIII");



        final ScaleAnimation scaleAnimation = new ScaleAnimation(1.0f,1.2f,1.0f,1.2f, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);
        scaleAnimation.setDuration(25);
        scaleAnimation.setFillAfter(true);

        //final TranslateAnimation scaleAnimationPLUSONE = new TranslateAnimation();
        final ScaleAnimation scaleAnimationPLUSONE  = new ScaleAnimation(1.0f,1.5f,1.0f,1.5f, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);
        scaleAnimationPLUSONE.setDuration(200);
        scaleAnimationPLUSONE.setFillAfter(true);







        scaleAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                final ScaleAnimation scaleAnimation2 = new ScaleAnimation(1.2f,1.0f,1.2f,1.0f, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);
                scaleAnimation2.setDuration(25);
                KI.startAnimation(scaleAnimation2);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        scaleAnimationPLUSONE.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {

                layout.removeView(plusOne);
                //plusOne.animate().translationX(-30).setDuration(200);


            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        KI.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layout.removeView(plusOne);
                v.startAnimation(scaleAnimation);
                kookies.getAndAdd(1);
                score.setText("Kulfis: " + kookies+ "");
                layout.addView(plusOne);

                ConstraintSet cs = new ConstraintSet();
                cs.clone(layout);

                cs.connect(plusOne.getId(), ConstraintSet.TOP, layout.getId(), ConstraintSet.TOP);
                cs.connect(plusOne.getId(), ConstraintSet.BOTTOM, layout.getId(), ConstraintSet.BOTTOM);
                cs.connect(plusOne.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.LEFT);
                cs.connect(plusOne.getId(), ConstraintSet.RIGHT, layout.getId(), ConstraintSet.RIGHT);
                float randOne = 0f;
                float randTwo = 0f;
                while(randOne < .35f || randOne > .65f)
                {
                    randOne = (float) Math.random();
                }
                while(randTwo < .25f || randTwo > .75f)
                {
                    randTwo = (float) Math.random();
                }
                cs.setHorizontalBias(plusOne.getId(), randTwo);
                cs.setVerticalBias(plusOne.getId(), randOne);

                cs.applyTo(layout);

                //plusOne.animate().translationYBy(30).translationXBy(0).setDuration(200);

                //plusOne.setX(randTwo);
                plusOne.setTranslationY(randOne);
                plusOne.animate().translationYBy(-200f);
                //plusOne.setTranslationY();



                plusOne.startAnimation(scaleAnimationPLUSONE);


                added();





            }
        });

        fridge.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(kookies.get() >= 10)
                {
                    ImageView upgradeFridgeImage;

                    upgradeFridgeImage = new ImageView(activity);
                    upgradeFridgeImage.setImageResource(R.drawable.fridge);
                    upgradeFridgeImage.setId(View.generateViewId());
                    //upgradeFridgeImage.setAdjustViewBounds(jj);

                    ConstraintLayout.LayoutParams wap = new ConstraintLayout.LayoutParams(200, 200);
                    upgradeFridgeImage.setLayoutParams(wap);

                    fridges++;
                    kookies.getAndAdd(-10);

                    if(kookies.get() < 10)
                    {
                        final ScaleAnimation fridgeAnimation  = new ScaleAnimation(1.0f,0f,1.0f,0f, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);

                        fridgeAnimation.setDuration(1000);
                        Log.d("H", "WHY");
                        fridge.startAnimation(fridgeAnimation);
                    }

                    layout.addView(upgradeFridgeImage);
                    ConstraintSet cs = new ConstraintSet();
                    cs.clone(layout);

                    cs.connect(upgradeFridgeImage.getId(), ConstraintSet.TOP, layout.getId(), ConstraintSet.TOP);
                    cs.connect(upgradeFridgeImage.getId(), ConstraintSet.BOTTOM, layout.getId(), ConstraintSet.BOTTOM);
                    cs.connect(upgradeFridgeImage.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.LEFT);
                    cs.connect(upgradeFridgeImage.getId(), ConstraintSet.RIGHT, layout.getId(), ConstraintSet.RIGHT);
                    float randOne = 0f;
                    float randTwo = 0f;
                    while(randOne < .85f || randOne > 1.0f)
                    {
                        randOne = (float) Math.random();
                    }
                    while(randTwo < .05f || randTwo > .95f)
                    {
                        randTwo = (float) Math.random();
                    }
                    cs.setHorizontalBias(upgradeFridgeImage.getId(), randTwo);
                    cs.setVerticalBias(upgradeFridgeImage.getId(), randOne);

                    System.out.println(randTwo + "" + randOne);
                    cs.applyTo(layout);

                    upgradeFridgeImage.setVisibility(View.VISIBLE);
                }


                added();

            }
        });

        truck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(kookies.get() >= 50)
                {
                    ImageView upgradeFridgeImage;

                    upgradeFridgeImage = new ImageView(activity);
                    upgradeFridgeImage.setImageResource(R.drawable.truck);
                    upgradeFridgeImage.setId(View.generateViewId());
                    //upgradeFridgeImage.setAdjustViewBounds(jj);

                    ConstraintLayout.LayoutParams wap = new ConstraintLayout.LayoutParams(200, 200);
                    upgradeFridgeImage.setLayoutParams(wap);

                    trucks++;
                    kookies.getAndAdd(-50);

                    if(kookies.get() < 50)
                    {
                        final ScaleAnimation fridgeAnimation  = new ScaleAnimation(1.0f,0f,1.0f,0f, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);

                        fridgeAnimation.setDuration(1000);
                        Log.d("H", "WHY");
                        truck.startAnimation(fridgeAnimation);
                    }

                    layout.addView(upgradeFridgeImage);
                    ConstraintSet cs = new ConstraintSet();
                    cs.clone(layout);

                    cs.connect(upgradeFridgeImage.getId(), ConstraintSet.TOP, layout.getId(), ConstraintSet.TOP);
                    cs.connect(upgradeFridgeImage.getId(), ConstraintSet.BOTTOM, layout.getId(), ConstraintSet.BOTTOM);
                    cs.connect(upgradeFridgeImage.getId(), ConstraintSet.LEFT, layout.getId(), ConstraintSet.LEFT);
                    cs.connect(upgradeFridgeImage.getId(), ConstraintSet.RIGHT, layout.getId(), ConstraintSet.RIGHT);
                    float randOne = 0f;
                    float randTwo = 0f;
                    while(randOne < .85f || randOne > 1.0f)
                    {
                        randOne = (float) Math.random();
                    }
                    while(randTwo < .05f || randTwo > .95f)
                    {
                        randTwo = (float) Math.random();
                    }
                    cs.setHorizontalBias(upgradeFridgeImage.getId(), randTwo);
                    cs.setVerticalBias(upgradeFridgeImage.getId(), randOne);

                    System.out.println(randTwo + "" + randOne);
                    cs.applyTo(layout);

                    upgradeFridgeImage.setVisibility(View.VISIBLE);
                }


                added();
            }
        });


    }

    public void added()
    {
        score.setText("Kulfis: " + kookies+ "");
        if(kookies.get() >= 10){

            if(!fridgeIsVisible)
            {
                final ScaleAnimation fridgeAnimation  = new ScaleAnimation(0f,1.0f,0f,1.0f, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);

                fridgeAnimation.setDuration(1000);
                Log.d("H", "WHY");
                fridge.startAnimation(fridgeAnimation);
            }
            fridgeIsVisible = true;
            fridge.setVisibility(View.VISIBLE);

            //TranslateAnimation fridgeAnimation = new TranslateAnimation(1.0f, 0f, 7f, 7f);


        }
        else
        {
            fridgeIsVisible = false;
            fridge.setVisibility(View.INVISIBLE);
        }
        if(kookies.get() >= 50){

            if(!truckIsVisible)
            {
                final ScaleAnimation fridgeAnimation  = new ScaleAnimation(0f,1.0f,0f,1.0f, Animation.RELATIVE_TO_SELF, .5f, Animation.RELATIVE_TO_SELF, .5f);

                fridgeAnimation.setDuration(1000);
                Log.d("H", "WHY");
                truck.startAnimation(fridgeAnimation);
            }
            truckIsVisible = true;
            truck.setVisibility(View.VISIBLE);

            //TranslateAnimation fridgeAnimation = new TranslateAnimation(1.0f, 0f, 7f, 7f);


        }
        else
        {
            truckIsVisible = false;
            truck.setVisibility(View.INVISIBLE);
        }
    }

    public class fridgeThread extends Thread
    {

        public void run()
        {
            int cycles = 0;
            while (true)
            {

                try {
                    Thread.sleep(250);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if(cycles == 3)
                {
                    for(int i = 0; i < fridges; i++)
                    {

                        kookies.getAndAdd(1);


                    }
                    cycles = 0;
                }
                cycles++;

                for(int i = 0; i <trucks; i++)
                {
                    kookies.getAndAdd(1);
                }

                int per = 0;
                per+=fridges;
                per+= ((trucks)*4);

                int finalPer = per;

                activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    added();
                    CPS.setText("KPS: " + finalPer);
                }
            });

            }

        }
    }
}